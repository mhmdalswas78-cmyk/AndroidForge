package com.example.mt5scalper

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : ComponentActivity() {
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { Dashboard() } }
}

private fun request(base: String, token: String, path: String, payload: JSONObject? = null): String {
 require(base.startsWith("https://")) { "استخدم عنوان HTTPS فقط" }
 val conn = URL(base.trimEnd('/') + path).openConnection() as HttpURLConnection
 try {
  conn.connectTimeout = 7000; conn.readTimeout = 7000
  conn.setRequestProperty("X-Control-Token", token)
  if (payload != null) {
   conn.requestMethod = "POST"; conn.doOutput = true
   conn.setRequestProperty("Content-Type", "application/json")
   conn.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
  }
  val code = conn.responseCode
  val stream = if (code in 200..299) conn.inputStream else conn.errorStream
  val body = stream?.bufferedReader()?.use { it.readText() } ?: ""
  if (code !in 200..299) error("HTTP $code: $body")
  return body
 } finally { conn.disconnect() }
}

@Composable
fun Dashboard() {
 var server by remember { mutableStateOf("") }
 var token by remember { mutableStateOf("") }
 var account by remember { mutableStateOf("") }
 var mode by remember { mutableStateOf("demo") }
 var status by remember { mutableStateOf("غير متصل") }
 var busy by remember { mutableStateOf(false) }
 val scope = rememberCoroutineScope()
 fun run(action: suspend () -> String) {
  scope.launch { busy = true; status = try { withContext(Dispatchers.IO) { action() } } catch(e:Exception) { "خطأ: ${e.message}" }; busy = false }
 }
 MaterialTheme(colorScheme = darkColorScheme()) {
  Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp), verticalArrangement=Arrangement.spacedBy(14.dp)) {
   Text("MT5 • Scalping Robot", style=MaterialTheme.typography.headlineMedium)
   Text("الذهب والفوركس | المخاطرة المستهدفة 0.01% لكل صفقة")
   OutlinedTextField(server,{server=it},label={Text("رابط خادم HTTPS")},modifier=Modifier.fillMaxWidth(),singleLine=true)
   OutlinedTextField(token,{token=it},label={Text("رمز التحكم السري")},visualTransformation=PasswordVisualTransformation(),modifier=Modifier.fillMaxWidth(),singleLine=true)
   OutlinedTextField(account,{account=it.filter(Char::isDigit)},label={Text("رقم حساب MT5")},modifier=Modifier.fillMaxWidth(),singleLine=true)
   Text("اختر نوع الحساب")
   Row { RadioButton(mode=="demo",{mode="demo"});Text("Demo",modifier=Modifier.padding(top=12.dp));Spacer(Modifier.width(18.dp));RadioButton(mode=="real",{mode="real"});Text("Real",modifier=Modifier.padding(top=12.dp)) }
   Button(enabled=!busy,onClick={run { request(server,token,"/status") }},modifier=Modifier.fillMaxWidth()){Text("تسجيل الاتصال / تحديث حالة الحسابات")}
   Button(enabled=!busy && account.isNotBlank(),onClick={run {
    request(server,token,"/command",JSONObject().put("account",account).put("mode",mode).put("enabled",true))
   }},modifier=Modifier.fillMaxWidth()){Text("▶ تشغيل الروبوت")}
   OutlinedButton(enabled=!busy && account.isNotBlank(),onClick={run {
    request(server,token,"/command",JSONObject().put("account",account).put("mode",mode).put("enabled",false))
   }},modifier=Modifier.fillMaxWidth()){Text("■ إيقاف فتح صفقات جديدة")}
   Text(status)
   Text("مهم: يتطلب تشغيل MT5 على ويندوز/VPS وتفعيل WebRequest. الإيقاف لا يغلق الصفقات المفتوحة.",style=MaterialTheme.typography.bodySmall)
  }
 }
}
